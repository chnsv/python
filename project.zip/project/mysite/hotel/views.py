from django.shortcuts import render, get_object_or_404, redirect
from .models import Hotel, Guest, Reservation
from .forms import HotelForm, GuestForm, ReservationForm, HotelEditForm


def home(request):
    hotels = Hotel.objects.all()
    guests = Guest.objects.all()
    reservations = Reservation.objects.all()
    return render(request, 'templates/home.html', {
        'hotels': hotels,
        'guests': guests,
        'reservations': reservations,
    })

def hotels_list(request):
    hotels = Hotel.objects.all()
    return render(request, 'hotels_list.html', {'hotels': hotels})
def guests_list(request):
    guests = Guest.objects.all()
    return render(request, 'guests_list.html', {'guests': guests})
def reservations_list(request):
    reservations = Reservation.objects.all()
    return render(request, 'reservations_list.html', {'reservations': reservations})

def hotel_detail(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    reservations = Reservation.objects.filter(hotel=hotel)
    guests = Guest.objects.all()
    return render(request, 'hotel_detail.html', {
        'hotel': hotel,
        'reservations': reservations,
        'guests': guests,
    })
def guest_detail(request, guest_id):
    guest = get_object_or_404(Guest, id=guest_id)
    reservations = Reservation.objects.filter(guest=guest).order_by('-check_in_date')

    return render(request, 'guest_detail.html', {
        'guest': guest,
        'reservations': reservations,
    })
def reservation_detail(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id)
    hotel = reservation.hotel
    guest = reservation.guest

    return render(request, 'reservation_detail.html', {
        'reservation': reservation,
        'hotel': hotel,
        'guest': guest,
    })

def add_hotel(request):
    if request.method == 'POST':
        form = HotelForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('hotels_list')
    else:
        form = HotelForm()
    return render(request, 'add_hotel.html', {'form': form})
def edit_hotel(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    if request.method == 'POST':
        form = HotelEditForm(request.POST, instance=hotel)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', hotel.id)
    else:
        form = HotelEditForm(instance=hotel)
    return render(request, 'edit_hotel.html', {'form': form, 'hotel': hotel})

def add_guest(request):
    if request.method == 'POST':
        form = GuestForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('hotels_list')
    else:
        form = GuestForm()
    return render(request, 'add_guest.html', {'form': form})

def edit_guest(request, guest_id):
    guest = get_object_or_404(Guest, id=guest_id)
    if request.method == 'POST':
        form = GuestForm(request.POST, instance=guest)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', guest.hotel.id)
    else:
        form = GuestForm(instance=guest)
    return render(request, 'edit_guest.html', {'form': form, 'guest': guest})

def add_reservation(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', form.cleaned_data['hotel'].id)
    else:
        form = ReservationForm()
    return render(request, 'add_reservation.html', {'form': form})

def edit_reservation(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id)
    if request.method == 'POST':
        form = ReservationForm(request.POST, instance=reservation)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', reservation.hotel.id)
    else:
        form = ReservationForm(instance=reservation)
    return render(request, 'edit_reservation.html', {'form': form, 'reservation': reservation})
