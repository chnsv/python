from django.shortcuts import render, get_object_or_404, redirect
from .models import Hotel, Guest, Reservation
from .forms import HotelForm, GuestForm, ReservationForm, HotelEditForm, GuestEditForm, ReservationEditForm


def home(request):
    hotels = Hotel.objects.all()
    guests = Guest.objects.all()
    reservations = Reservation.objects.all()
    return render(request, 'home.html', {
        'hotels': hotels,
        'guests': guests,
        'reservations': reservations,
    })

def add_hotel(request):
    if request.method == 'POST':
        form = HotelForm(request.POST)
        if form.is_valid():
            hotel = form.save()
            return redirect('home')  # Перенаправление на главную страницу после успешной добавки
    else:
        form = HotelForm()
    return render(request, 'add_hotel.html', {'form': form})

def add_guest(request):
    if request.method == 'POST':
        form = GuestForm(request.POST)
        if form.is_valid():
            guest = form.save()
            return redirect('home')  # Перенаправление на главную страницу после успешной добавки
    else:
        form = GuestForm()
    return render(request, 'add_guest.html', {'form': form})

def add_reservation(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            reservation = form.save()
            return redirect('hotel_detail', reservation.hotel.id)  # Перенаправление на детальную страницу гостиницы
    else:
        form = ReservationForm()
    return render(request, 'add_reservation.html', {'form': form})

def hotel_detail(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    reservations = Reservation.objects.filter(hotel=hotel)
    guests = Guest.objects.all()
    return render(request, 'hotel_detail.html', {
        'hotel': hotel,
        'reservations': reservations,
        'guests': guests,
    })
def guest_detail(request, guest_id):
    guest = get_object_or_404(Guest, id=guest_id)
    reservations = Reservation.objects.filter(guest=guest).order_by('-check_in_date')

    return render(request, 'guest_detail.html', {
        'guest': guest,
        'reservations': reservations,
    })
def reservation_detail(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id)
    hotel = reservation.hotel
    guest = reservation.guest

    return render(request, 'reservation_detail.html', {
        'reservation': reservation,
        'hotel': hotel,
        'guest': guest,
    })

def edit_hotel(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    if request.method == 'POST':
        form = HotelEditForm(request.POST, instance=hotel)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', hotel.id)
    else:
        form = HotelEditForm(instance=hotel)
    return render(request, 'edit_hotel.html', {'form': form, 'hotel': hotel})


def edit_guest(request, guest_id):
    guest = get_object_or_404(Guest, id=guest_id)
    if request.method == 'POST':
        form = GuestEditForm(request.POST, instance=guest)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', guest.hotel.id)
    else:
        form = GuestEditForm(instance=guest)
    return render(request, 'edit_guest.html', {'form': form, 'guest': guest})


def edit_reservation(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id)
    if request.method == 'POST':
        form = ReservationEditForm(request.POST, instance=reservation)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', reservation.hotel.id)
    else:
        form = ReservationEditForm(instance=reservation)
    return render(request, 'edit_reservation.html', {'form': form, 'reservation': reservation})

def delete_hotel(request, id):
    hotel = get_object_or_404(Hotel, id=id)
    hotel.delete()
    return redirect('home')

def delete_guest(request, guest_id):
    guest = get_object_or_404(Guest, id=guest_id)
    if request.method == 'POST':
        guest.delete()
        return redirect('home')
    return render(request, 'delete_guest.html', {'guest': guest})

def delete_reservation(request, reservation_id):
    reservation = get_object_or_404(Reservation, id=reservation_id)
    if request.method == 'POST':
        reservation.delete()
        return redirect('hotel_detail', reservation.hotel.id)
    return render(request, 'delete_reservation.html', {'reservation': reservation})