from django.shortcuts import render, get_object_or_404, redirect
from .models import Hotel, Guest, Reservation
from .forms import HotelForm, GuestForm, ReservationForm, HotelEditForm


def home(request):
    hotels = Hotel.objects.all()
    guests = Guest.objects.all()
    reservations = Reservation.objects.all()
    return render(request, 'home.html', {
        'hotels': hotels,
        'guests': guests,
        'reservations': reservations,
    })

def add_hotel(request):
    if request.method == 'POST':
        form = HotelForm(request.POST)
        if form.is_valid():
            hotel = form.save()
            return redirect('home')  # Перенаправление на главную страницу после успешной добавки
    else:
        form = HotelForm()
    return render(request, 'add_hotel.html', {'form': form})

def add_guest(request):
    if request.method == 'POST':
        form = GuestForm(request.POST)
        if form.is_valid():
            guest = form.save()
            return redirect('home')  # Перенаправление на главную страницу после успешной добавки
    else:
        form = GuestForm()
    return render(request, 'add_guest.html', {'form': form})

def add_reservation(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            reservation = form.save()
            return redirect('hotel_detail', reservation.hotel.id)  # Перенаправление на детальную страницу гостиницы
    else:
        form = ReservationForm()
    return render(request, 'add_reservation.html', {'form': form})

def hotel_detail(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    return render(request, 'hotel_detail.html', {'hotel': hotel})

def edit_hotel(request, hotel_id):
    hotel = get_object_or_404(Hotel, id=hotel_id)
    if request.method == 'POST':
        form = HotelEditForm(request.POST, instance=hotel)
        if form.is_valid():
            form.save()
            return redirect('hotel_detail', hotel.id)
    else:
        form = HotelEditForm(instance=hotel)
    return render(request, 'edit_hotel.html', {'form': form, 'hotel': hotel})