from django import forms
from .models import Hotel, Guest, Reservation


class HotelForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = ['name', 'address', 'city', 'country', 'star_rating', 'price_per_night']


class GuestForm(forms.ModelForm):
    class Meta:
        model = Guest
        fields = ['first_name', 'last_name', 'email']


class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['hotel', 'guest', 'check_in_date', 'check_out_date']


class HotelEditForm(forms.ModelForm):
    class Meta:
        model = Hotel
        fields = ['name', 'address', 'city', 'country', 'star_rating', 'price_per_night']


