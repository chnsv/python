from django.urls import path, include
from django.conf import settings
from django.contrib.sitemaps.views import sitemap
from . import views

urlpatterns = [
    # Главная страница
    path('', views.home, name='home'),

    # Гостиницы
    path('hotel/', views.home, name='hotels_list'),
    path('hotel/<int:hotel_id>/', views.hotel_detail, name='hotel_detail'),
    path('add_hotel/', views.add_hotel, name='add_hotel'),
    path('edit/<int:hotel_id>/', views.edit_hotel, name='edit_hotel'),

    # Гости
    path('guests/', views.home, name='guests_list'),
    path('add_guest/', views.add_guest, name='add_guest'),

    # Бронирования
    path('reservations/', views.home, name='reservations_list'),
    path('add_reservation/', views.add_reservation, name='add_reservation'),

    path('edit/<int:id>/', views.edit_hotel, name='edit_hotel'),
    path('detail/<int:hotel_id>/', views.hotel_detail, name='hotel_detail'),
]
