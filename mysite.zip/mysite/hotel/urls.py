from django.urls import path, include
from django.conf import settings
from django.contrib.sitemaps.views import sitemap
from . import views

urlpatterns = [
    # Главная страница
    path('', views.home, name='home'),

    # Гостиницы
    path('hotel/', views.home, name='hotels_list'),
    path('hotel/<int:hotel_id>/', views.hotel_detail, name='hotel_detail'),
    path('add_hotel/', views.add_hotel, name='add_hotel'),
    path('edit_hotel/<int:hotel_id>/', views.edit_hotel, name='edit_hotel'),

    # Гости
    path('guests/', views.home, name='guests_list'),
    path('guest/<int:guest_id>/', views.guest_detail, name='guest_detail'),
    path('add_guest/', views.add_guest, name='add_guest'),
    path('edit_guest/<int:guest_id>/', views.edit_guest, name='edit_guest'),

    # Бронирования
    path('reservations/', views.home, name='reservations_list'),
    path('reservation/<int:reservation_id>/', views.reservation_detail, name='reservation_detail'),
    path('add_reservation/', views.add_reservation, name='add_reservation'),
    path('edit_reservation/<int:reservation_id>/', views.edit_reservation, name='edit_reservation'),

    # Сitemap
    #path('sitemap.xml', sitemap, {'sitemaps': settings.SITEMAPS}, name='sitemap'),

    path('add/hotel/', views.add_hotel, name='add_hotel'),
    path('edit/<int:id>/', views.edit_hotel, name='edit_hotel'),
    path('delete/<int:id>/', views.delete_hotel, name='delete_hotel'),
    path('add/guest/', views.add_guest, name='add_guest'),
    path('edit/<int:id>/', views.edit_guest, name='edit_guest'),
    path('delete/<int:id>/', views.delete_guest, name='delete_guest'),
    path('add/reservation/', views.add_reservation, name='add_reservation'),
    path('edit/<int:id>/', views.edit_reservation, name='edit_reservation'),
    path('delete/<int:id>/', views.delete_reservation, name='delete_reservation'),
]
