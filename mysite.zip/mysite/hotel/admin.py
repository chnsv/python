from django.contrib import admin
from .models import Hotel, Guest, Reservation

class HotelAdmin(admin.ModelAdmin):
    list_display = ('name', 'address', 'city', 'country', 'star_rating', 'price_per_night')
    search_fields = ('name', 'city', 'country')
    list_filter = ('star_rating',)
    readonly_fields = ('price_per_night',)

class GuestAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'email')
    search_fields = ('first_name', 'last_name', 'email')

class ReservationAdmin(admin.ModelAdmin):
    list_display = ('hotel', 'guest', 'check_in_date', 'check_out_date')
    search_fields = ('hotel__name', 'guest__first_name')
    list_filter = ('check_in_date',)
    raw_id_fields = ('hotel', 'guest')

admin.site.register(Hotel, HotelAdmin)
admin.site.register(Guest, GuestAdmin)
admin.site.register(Reservation, ReservationAdmin)
